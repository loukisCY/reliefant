USE releifant;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS doctors;
DROP TABLE IF EXISTS patients;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE Doctors(
	UID INT NOT NULL AUTO_INCREMENT,
    national_id INT UNIQUE NOT NULL,
    first_name VARCHAR(20) NOT NULL,
    last_name VARCHAR(20) NOT NULL,
    email VARCHAR(50),
    password VARCHAR(50) NOT NULL,
    
    PRIMARY KEY(UID)
    );
    
CREATE TABLE Patients(
	UID INT NOT NULL AUTO_INCREMENT,
    national_id INT NOT NULL,
    first_name VARCHAR(20) NOT NULL,
    last_name VARCHAR(20) NOT NULL,
    email VARCHAR(50) UNIQUE NOT NULL,
    doctor_uid INT NOT NULL,
    
    PRIMARY KEY(UID),
    FOREIGN KEY (doctor_uid) REFERENCES Doctors(UID)
    );
    