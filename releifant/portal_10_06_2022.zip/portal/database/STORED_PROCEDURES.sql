USE releifant;

DROP PROCEDURE IF EXISTS Login;
DROP PROCEDURE IF EXISTS GetPatients;
DROP PROCEDURE IF EXISTS GetPatientDetails;

DELIMITER $$
CREATE PROCEDURE Login (email varchar(50), password varchar(50))
BEGIN
SELECT UID, first_name, last_name, email
FROM Doctors D WHERE D.email = email AND D.password = password;
END
$$

CREATE PROCEDURE GetPatients (doc_uid int)
BEGIN
SELECT * 
FROM Patients P
WHERE P.doctor_uid = doc_uid
ORDER BY first_name, last_name;
END
$$

CREATE PROCEDURE GetPatientDetails (doc_uid int, pat_uid int)
BEGIN
SELECT *
FROM Patients P
WHERE P.doctor_uid = doc_uid AND P.UID = pat_uid;
END
$$

-- CALL Login('marios@gmail.com','hello123');
-- CALL GetPatients(1);
-- CALL GetPatientDetails(1, 1);
