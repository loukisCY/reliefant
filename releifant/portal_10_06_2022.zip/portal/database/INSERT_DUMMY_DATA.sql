INSERT INTO Doctors(national_id, first_name, last_name, email, password) 
VALUES(1013129, 'Loukas', 'Papalazarou', 'loukas26@gmail.com', '123');

INSERT INTO Doctors(national_id, first_name, last_name, email, password) 
VALUES(1013245, 'Marios', 'Papalazarou', 'marios@gmail.com', '123');

INSERT INTO Doctors(national_id, first_name, last_name, email, password) 
VALUES(1013125, 'Mixalis', 'Mixail', 'mike@gmail.com', '123');

INSERT INTO Doctors(national_id, first_name, last_name, email, password) 
VALUES(1013121, 'Antreas', 'Andreaou', 'andys@gmail.com', '123');

--------

INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (9062018, "Myles", "Shepard", "Myles906@gmail.com", 1);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (1945706, "Ryland", "Valenzuela", "Ryland194@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (3053130, "Gerardo", "Fuller", "Gerardo305@gmail.com", 1);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (7460236, "Susan", "Prince", "Susan746@gmail.com", 1);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (2263317, "Yusuf", "Guzman", "Yusuf226@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (7679446, "Giovanni", "Murillo", "Giovanni767@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (4050843, "Trent", "Hardy", "Trent405@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (6644150, "Donald", "Stein", "Donald664@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (8349862, "Nia", "Mata", "Nia834@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (7217470, "Amaris", "Hamilton", "Amaris721@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (9217841, "Nola", "Ferguson", "Nola921@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (7434417, "Aniyah", "Salas", "Aniyah743@gmail.com", 1);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (6521910, "Audrina", "Raymond", "Audrina652@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (3904275, "Chase", "Woods", "Chase390@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (7479708, "Saul", "Conner", "Saul747@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (4853873, "Gaige", "Porter", "Gaige485@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (4074237, "Francisco", "Gentry", "Francisco407@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (8873550, "Trey", "Odom", "Trey887@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (5701131, "Makenna", "Bautista", "Makenna570@gmail.com", 1);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (1801601, "Aimee", "Hopkins", "Aimee180@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (2903720, "Anabelle", "Bentley", "Anabelle290@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (7914305, "Cordell", "Ho", "Cordell791@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (9104352, "Adan", "Barrett", "Adan910@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (6486189, "Bryant", "Decker", "Bryant648@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (2070984, "Sarai", "Carr", "Sarai207@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (9051310, "Aiden", "Cameron", "Aiden905@gmail.com", 1);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (3783480, "Kenzie", "Ware", "Kenzie378@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (1413205, "Arianna", "Love", "Arianna141@gmail.com", 1);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (5478830, "Elsie", "Day", "Elsie547@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (6716489, "Sage", "Nicholson", "Sage671@gmail.com", 1);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (8758423, "Miriam", "Bush", "Miriam875@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (1398035, "Abagail", "Ho", "Abagail139@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (2147284, "Walker", "Reeves", "Walker214@gmail.com", 1);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (7591693, "Mekhi", "Randall", "Mekhi759@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (6501331, "Soren", "Case", "Soren650@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (1474335, "Gerald", "Orr", "Gerald147@gmail.com", 1);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (6005583, "Kaydence", "Medina", "Kaydence600@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (3621295, "Rebekah", "Wilson", "Rebekah362@gmail.com", 1);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (2931835, "Alyvia", "May", "Alyvia293@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (2802546, "Madalynn", "Downs", "Madalynn280@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (9322726, "Winston", "Cervantes", "Winston932@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (7381951, "Spencer", "Castaneda", "Spencer738@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (4266546, "Cael", "Phillips", "Cael426@gmail.com", 1);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (9849427, "Brennan", "Franco", "Brennan984@gmail.com", 1);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (5414818, "Van", "Chavez", "Van541@gmail.com", 1);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (2487326, "Mylie", "Cannon", "Mylie248@gmail.com", 3);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (6374406, "Darion", "Bullock", "Darion637@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (6900791, "Janiya", "Valenzuela", "Janiya690@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (6418317, "Kaiden", "Leonard", "Kaiden641@gmail.com", 2);
INSERT INTO Patients(national_id, first_name, last_name, email, doctor_uid) VALUES (7696801, "Abigayle", "Sloan", "Abigayle769@gmail.com", 3);

select * from Doctors;
select * from Patients;

		