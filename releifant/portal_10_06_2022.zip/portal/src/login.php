<?php

session_start();
include "db.php";
if(isset($_POST['submit'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    mysqli_query($conn ,"SET @p0='".$email."'");
    mysqli_query($conn ,"SET @p1='".$password."'");

    $sql = "CALL Login (@p0,@p1)";
    $result = $conn -> query($sql);

    if ($result->num_rows > 0){
        $row = $result->fetch_assoc();

        $_SESSION['UID'] = $row["UID"];
        $_SESSION['first_name'] = $row["first_name"];
        $_SESSION['last_name'] = $row["last_name"];
        $_SESSION['email'] = $row["email"];

        $_SESSION['logged_in'] = true;
        header("location:dashboard.php");
    }
    else{
        header("location:login.php");
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="assets/favicon.png" />
    <title>Releifant | Login</title>

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link href="css/login_styles.css" rel="stylesheet">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->
</head>

<script>
function myFunction() {
    var x = document.getElementById("inputPassword");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
</script>

<body>
    <!--
    you can substitue the span of reauth email for a input with the email and
    include the remember me checkbox
    -->
    <div class="container">
        <br>
        <h1 style="text-align: center; font-weight: bolder;">Releifant Doctors Portal<br><br>Please Login</h1>
        <div class="card card-container">
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
            <img id="profile-img" class="profile-img-card" src="assets/doc.png" />
            <p id="profile-name" class="profile-name-card"></p>
            <form class="form-signin" method="post">
                <span id="reauth-email" class="reauth-email"></span>
                <input type="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus
                    name="email">
                <input type="password" id="inputPassword" class="form-control" placeholder="Password" required
                    name="password">
                <input type="checkbox" onclick="myFunction()">Show Password<br><br>
                <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit" name="submit">Login</button>
            </form><!-- /form -->
            <a href="" class="forgot-password">
                Forgot the password?
            </a>
        </div><!-- /card-container -->
    </div><!-- /container -->
</body>

</html>