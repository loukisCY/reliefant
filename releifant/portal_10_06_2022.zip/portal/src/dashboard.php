<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="icon" type="image/png" href="assets/favicon.png" />
    <script src="js/index.js"></script>
    <link href="css/dashboard_styles.css" rel="stylesheet">
    <title>Releifant | Dashboard</title>
</head>

<script>
function show_patient(str) {
    if (str == "") {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET", "getpatient.php?q=" + str, true);
        xmlhttp.send();
    }
}
</script>

<body>
    <?php
session_start();

if (!isset($_SESSION['logged_in'])) header("Location: login.php");

else
{
    echo "<nav class='navbar sticky-top navbar-dark bg-dark'>";
    echo "<h2 style='color:white;'>Welcome Dr. " . $_SESSION['last_name'] . "</h2>";
    echo "<ul class='navbar-nav ml-auto'><li class='nav-item'><a href='logout.php'><input type='Submit' value='Logout'></a></li>";
    echo "</nav>";
}

?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm">

                <?php
include "db.php";
mysqli_query($conn, "SET @p0='" . $_SESSION["UID"] . "'");
$sql = "CALL GetPatients (@p0)";
$result = $conn->query($sql);
if ($result->num_rows > 0)
{
    echo "<table>";
    echo "<tr>";
    echo "<th>ID</th> <th>Firstname</th> <th>Lastname</th> <th>Details</th>";
    while ($row = $result->fetch_assoc())
    {
        echo "<tr>";
        echo "<td>" . $row["national_id"] . "</td><td>" . $row["first_name"] . "</td><td>" . $row["last_name"] . "</td>";
        echo "<td><input type='Submit' value='See details' onclick='show_patient(" . $row["UID"] . ")'></td>";
        echo "</tr>";
    }
    echo "</table>";
}
else
{
    echo "<h2>No Patients</h2>";
}
// Free result set
$result->close();
$conn->next_result();

?>
            </div>
            <!-- FIX BACK BUTTON-->
            <div class="col-sm">
                <div id="txtHint" style="width: 50%; margin: 0 auto;">
                    <h4>Person info will be listed here.</h4>
                </div>
                <button onclick="backToTop()" id="myBtn"
                    style="position: fixed;bottom: 20px; right: 20px; display: none;"><svg
                        xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor"
                        class="bi bi-arrow-up-circle-fill" viewBox="0 0 16 16">
                        <path
                            d="M16 8A8 8 0 1 0 0 8a8 8 0 0 0 16 0zm-7.5 3.5a.5.5 0 0 1-1 0V5.707L5.354 7.854a.5.5 0 1 1-.708-.708l3-3a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 5.707V11.5z" />
                    </svg></button>
                <script type="text/javascript" src="js/toTop.js"></script>
            </div>
        </div>
</body>

</html>