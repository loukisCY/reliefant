<?php
session_start();
include "db.php";
if (!isset($_SESSION['logged_in'])) header("Location: login.php");

$q = intval($_GET['q']);

mysqli_query($conn, "SET @p0='" . $_SESSION["UID"] . "'");
mysqli_query($conn, "SET @p1='" . $q . "'");
$sql = "CALL GetPatientDetails (@p0, @p1)";
$result = $conn->query($sql);

$row = $result->fetch_assoc();
$profile_img_filename = 'profile_pictures/' . $row["national_id"] . '.png';
if (file_exists($profile_img_filename)){
    echo "<img src=' " . $profile_img_filename . " ' height='200px' width='200px' style=border-radius:50%;/><br>";
}
else{
    echo "<img src='profile_pictures/default.jpg' height='200px' width='200px' style=border-radius:50%;/><br>";
}

echo "<h2>" . $row["national_id"] . "<br>" . $row["first_name"] . "<br>" . $row["last_name"] . "<br>" . $row["email"] . "</h2><br>";
?>